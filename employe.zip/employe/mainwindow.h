#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include"employe.h"
#include "arduino.h"
#include <QMainWindow>
#include <QtCharts/QChartView>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>
#include <QtCharts>
#include <QTimer>
#include <QTableWidget>
#include <QtPrintSupport/QPrinter>
#include <QLabel>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

   void on_pushButton_ajouter_employe_clicked();
   void on_pushButton_supp_employe_clicked();
   void on_pushButton_modifier_employe_clicked();
   void on_pushButton_tri_id_employe_clicked();
   void on_pushButton_tri_age_employe_clicked();
   void on_pushButton_chercher_employe_clicked();
   void on_pushButton_rechercher_employe_clicked();
   void on_pushButton_PDF_clicked();
   void on_pushButton_employe_de_moit_employe_clicked();
   void on_pushButton_statstique_employe_clicked();
   void on_pushButton_chat_employe_clicked();
   void on_pushButton_OuvrirBlocNote_employe_clicked();
   void on_pushButton_age_statistique_employe_clicked();
   void on_pushButton_abs_statistique_employe_clicked();
   void on_pushButton_Word_clicked();
   void on_pushButton_heure_statistique_employe_clicked();
   void on_pushButton_tri_nom_employe_clicked();
   void on_pushButton_tri_prenom_employe_clicked();
   void on_pushButton_calculer_prime_employe_clicked();
   void on_pushButton_showQuestions_employe_clicked();
   void on_pushButton_conn_2_clicked();
   void on_pushButton_disconnect_clicked();
   void input();
   void on_table_employe_clicked(const QModelIndex &index);

private:
   QString ref;
       Ui::MainWindow *ui;
       employe e;
       QDialog *chartDialog;
       QStackedWidget *stackedWidget;
        QLabel *labelMessageSexe;
        QSqlQueryModel *model;
        Arduino a;
        int ret;
         QByteArray data;

};
#endif // MAINWINDOW_H
